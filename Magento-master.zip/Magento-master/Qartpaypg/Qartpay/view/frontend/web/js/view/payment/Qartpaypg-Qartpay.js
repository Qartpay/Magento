define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'Qartpay',
                component: 'Qartpaypg_Qartpay/js/view/payment/method-renderer/Qartpaypg-Qartpay'
            }
        );
        return Component.extend({});
    }
 );