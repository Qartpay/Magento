<?php

namespace Qartpaypg\Qartpay\Block\Info;

class Qartpay extends \Magento\Payment\Block\Info
{
    // protected $_template = 'Qartpaypg_Qartpay::info/Qartpay.phtml';
}
