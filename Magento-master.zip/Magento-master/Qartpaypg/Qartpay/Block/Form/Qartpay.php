<?php

namespace Qartpg\Qartpay\Block\Form;

class Qartpay extends \Magento\Payment\Block\Form
{
    protected $_template = 'Qartpaypg_Qartpay::form/Qartpay.phtml';
}