<?php

namespace Qartpaypg\Qartpay\Controller\Standard;

class Cancel extends \Qartpaypg\Qartpay\Controller\Qartpay
{

    public function execute()
    {
        $this->_cancelPayment();
        $this->_checkoutSession->restoreQuote();
        $this->getResponse()->setRedirect(
            $this->getQartpayHelper()->getUrl('checkout')
        );
    }

}
