<?php

namespace Qartpaypg\Qartpay\Controller\Standard;

class Redirect extends \Qartpaypg\Qartpay\Controller\Qartpay
{
    public function execute()
    {
        $promo='';
        if(isset($_GET['promo'])){
            if(trim($_GET['promo'])!=''){
                $promo=$_GET['promo'];
            }
        }
        $order = $this->getOrder();
        if ($order->getBillingAddress())
        {
            $order->setState("pending_payment")->setStatus("pending_payment");
            $order->addStatusToHistory($order->getStatus(), "Customer was redirected to Qartpay.");
            $order->save();
            
            if($promo!=''){
                $order->QartpayPromoCode=$promo;
            }

            $this->getResponse()->setRedirect(
                $this->getQartpayModel()->buildQartpayRequest($order)
            );
        }
        else
        {
            $this->_cancelPayment();
            $this->_QartpaySession->restoreQuote();
            $this->getResponse()->setRedirect(
                $this->getQartpayHelper()->getUrl('checkout')
            );
        }
    }
}