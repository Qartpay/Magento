<?php
 
class Qpay_Qartpay_Model_Mysql4_Qartpay extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {   
        $this->_init('Qartpay/Qartpay', 'Qartpay_id');
    }
