	<?php
//contains utility functions for encryption decrytion

class Qpay_Qartpay_Helper_Data2 extends Mage_Payment_Helper_Data
{
	/*	19751/17Jan2018	*/
		/*public $Qartpay_PAYMENT_URL_PROD = "https://secure.Qartpay.in/oltp-web/processTransaction";
		public $STATUS_QUERY_URL_PROD = "https://secure.Qartpay.in/oltp/HANDLER_INTERNAL/TXNSTATUS";
		public $Qartpay_PAYMENT_URL_TEST = "https://pguat.Qartpay.com/oltp-web/processTransaction";
		public $STATUS_QUERY_URL_TEST = "https://pguat.Qartpay.com/oltp/HANDLER_INTERNAL/TXNSTATUS";*/

		/*public $Qartpay_PAYMENT_URL_PROD = "https://securegw.Qartpay.in/theia/processTransaction";
		public $STATUS_QUERY_URL_PROD = "https://securegw.Qartpay.in/merchant-status/getTxnStatus";
		
		public $Qartpay_PAYMENT_URL_TEST = "https://securegw-stage.Qartpay.in/theia/processTransaction";
		public $STATUS_QUERY_URL_TEST = "https://securegw-stage.Qartpay.in/merchant-status/getTxnStatus";*/
	/*	19751/17Jan2018 end	*/
}
