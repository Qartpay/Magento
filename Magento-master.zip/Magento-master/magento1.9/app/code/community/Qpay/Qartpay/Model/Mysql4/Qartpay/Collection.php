<?php
 
class Qpay_Qartpay_Model_Mysql4_Qartpay_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
    public function _construct()
    {
        parent::__construct();
        $this->_init('Qartpay/Qartpay');
    }
}